<?php namespace App\Entities;

use CodeIgniter\Entity;

class Diskon extends Entity
{ 
	
}