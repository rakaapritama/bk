<?php namespace App\Entities;

use CodeIgniter\Entity;

class Barang extends Entity
{ 

}